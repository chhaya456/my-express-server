/////jshint eversion:6

const express = require("express");

const app = express();

///const port = 3000;

app.get("/",function(request,response){
  response.send("<h1>Hello Everyone!</h1>")
});

app.get("/about",function(req,res){
  res.send("<div>My name is Chhaya Parmar.I am Front End Web Developer. Here I am making one project based on localServer.</div>")
});
app.listen(3000, function(){
  console.log("Server is started on Port 3000!");
});
